import numpy as np
from numpy import exp, log
from scipy.special import gamma, digamma
import pickle
import time
from LDA_VI import LDA_VI

dir = "preprocessed_review.pickle"
lda = LDA_VI(dir, 0.1, 0.1, 10)
# # print(lda.alpha_star)
# # lda._update_theta_d()
# # lda._update_phi_t()
# # lda._update_theta_d()
lda.train(0.1)
print(lda._ELBO_history)





